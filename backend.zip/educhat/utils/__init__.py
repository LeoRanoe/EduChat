"""Utility functions and helpers."""

