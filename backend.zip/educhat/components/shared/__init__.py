"""Shared UI components for EduChat."""

from educhat.components.shared.logo import logo
from educhat.components.shared.buttons import (
    primary_button,
    secondary_button,
    icon_button,
    circular_button,
)
from educhat.components.shared.inputs import text_input, search_input
from educhat.components.shared.dropdown import dropdown
from educhat.components.shared.avatar import avatar
from educhat.components.shared.progress_bar import progress_bar, progress_dots
from educhat.components.shared.quiz_components import (
    multi_select_button,
    multi_select_group,
    checkbox_item,
    checkbox_list,
    radio_button,
    radio_group,
    text_area_input,
    dropdown_select,
)
from educhat.components.shared.mobile_nav import (
    hamburger_button,
    mobile_header,
    sidebar_overlay,
)
from educhat.components.shared.quick_actions import (
    quick_action_button,
    quick_actions_grid,
    conversation_template_button,
    conversation_templates,
)
from educhat.components.shared.follow_up_suggestions import (
    suggestion_chip,
    follow_up_suggestions,
    contextual_follow_ups,
    generate_contextual_suggestions,
)
from educhat.components.shared.reminders_modal import reminders_modal
from educhat.components.shared.events_panel import events_panel
from educhat.components.shared.settings_modal import settings_modal

__all__ = [
    "logo",
    "primary_button",
    "secondary_button",
    "icon_button",
    "circular_button",
    "text_input",
    "search_input",
    "dropdown",
    "avatar",
    "progress_bar",
    "progress_dots",
    "multi_select_button",
    "multi_select_group",
    "checkbox_item",
    "checkbox_list",
    "radio_button",
    "radio_group",
    "text_area_input",
    "dropdown_select",
    "hamburger_button",
    "mobile_header",
    "sidebar_overlay",
    "quick_action_button",
    "quick_actions_grid",
    "conversation_template_button",
    "conversation_templates",
    "suggestion_chip",
    "follow_up_suggestions",
    "contextual_follow_ups",
    "generate_contextual_suggestions",
    "reminders_modal",
    "events_panel",
    "settings_modal",
]

