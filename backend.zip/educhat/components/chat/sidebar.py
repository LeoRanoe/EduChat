"""Sidebar component for EduChat."""

import reflex as rx
from typing import List, Dict
from educhat.styles.theme import COLORS, RADIUS
from educhat.components.shared import logo, secondary_button, search_input, avatar
from educhat.state.app_state import AppState


def conversation_item(
    title: str,
    conversation_id: str,
    is_active=False,
    is_collapsed=False,
    on_click=None,
    on_delete=None,
    on_archive=None,
) -> rx.Component:
    """Single conversation item in sidebar list.
    
    Args:
        title: Conversation title
        conversation_id: Unique conversation ID
        is_active: Whether this is the active conversation
        is_collapsed: Whether sidebar is collapsed
        on_click: Click handler
        on_delete: Delete handler
        on_archive: Archive handler
    """
    return rx.box(
        rx.hstack(
            rx.icon(
                "message-circle",
                size=16,
                color=rx.cond(is_active, COLORS["white"], COLORS["text_tertiary"]),
                flex_shrink="0",
            ),
            # Show text only when not collapsed
            rx.cond(
                is_collapsed,
                rx.fragment(),
                rx.text(
                    title,
                    font_size="0.875rem",
                    color=rx.cond(is_active, COLORS["white"], COLORS["text_primary"]),
                    font_weight=rx.cond(is_active, "600", "500"),
                    white_space="nowrap",
                    overflow="hidden",
                    text_overflow="ellipsis",
                    flex="1",
                    letter_spacing="0.01em",
                    line_height="1.5",
                ),
            ),
            # Action buttons (show only when expanded and on hover)
            rx.cond(
                is_collapsed,
                rx.fragment(),
                rx.hstack(
                    rx.box(
                        rx.icon("trash-2", size=14, color=rx.cond(is_active, COLORS["white"], COLORS["text_tertiary"])),
                        on_click=AppState.delete_conversation(conversation_id),
                        cursor="pointer",
                        padding="0.375rem",
                        border_radius=RADIUS["md"],
                        opacity="0",
                        class_name="conv-action",
                        background="transparent",
                        _hover={
                            "background": COLORS["error"],
                            "color": COLORS["white"],
                            "transform": "scale(1.15)",
                        },
                        transition="all 0.25s cubic-bezier(0.4, 0, 0.2, 1)",
                    ),
                    spacing="1",
                    flex_shrink="0",
                ),
            ),
            spacing="3",
            align="center",
            width="100%",
            justify=rx.cond(is_collapsed, "center", "start"),
        ),
        background=rx.cond(
            is_active, 
            f"linear-gradient(135deg, {COLORS['primary_green']} 0%, {COLORS['dark_green']} 100%)",
            "transparent"
        ),
        border_radius=RADIUS["xl"],
        padding=rx.cond(is_collapsed, "0.75rem", "0.875rem 1.125rem"),
        margin=rx.cond(is_collapsed, "0.25rem 0.5rem", "0.25rem 0.875rem"),
        cursor="pointer",
        on_click=on_click,
        border=rx.cond(
            is_active,
            f"2px solid {COLORS['primary_green']}",
            "2px solid transparent"
        ),
        box_shadow=rx.cond(
            is_active,
            f"0 4px 16px {COLORS['primary_green']}30, 0 2px 4px rgba(0,0,0,0.1)",
            "0 1px 3px rgba(0,0,0,0.05)"
        ),
        _hover={
            "background": rx.cond(
                is_active, 
                f"linear-gradient(135deg, {COLORS['dark_green']} 0%, {COLORS['primary_green']} 100%)",
                f"{COLORS['light_green']}60"
            ),
            "transform": "translateX(4px) scale(1.01)",
            "box_shadow": f"0 6px 20px {COLORS['primary_green']}25, 0 3px 6px rgba(0,0,0,0.08)",
            "border_color": COLORS["primary_green"],
            ".conv-action": {"opacity": "1"},
        },
        transition="all 0.25s cubic-bezier(0.4, 0, 0.2, 1)",
    )


def sidebar(
    conversations: List[Dict] = [],
    current_conversation_id: str = "",
    on_new_conversation=None,
    on_search=None,
    on_conversation_click=None,
    user_name: str = "John Doe",
    user_email: str = "johndoe@email.com",
    is_open: bool = False,
    is_collapsed: bool = False,
    on_toggle_collapse=None,
) -> rx.Component:
    """Sidebar component with logo, search, and conversation list.
    
    Args:
        conversations: List of conversation dicts with 'id' and 'title'
        current_conversation_id: ID of active conversation
        on_new_conversation: Handler for new conversation button
        on_search: Handler for search input
        on_conversation_click: Handler for conversation click
        user_name: User's display name
        user_email: User's email
        is_open: Whether sidebar is open (for mobile)
    """
    return rx.box(
        rx.vstack(
            # Logo section with collapse button and gradient background
            rx.box(
                rx.vstack(
                    rx.hstack(
                        rx.cond(
                            is_collapsed,
                            rx.box(
                                rx.icon(
                                    "graduation-cap",
                                    size=24,
                                    color=COLORS["primary_green"],
                                ),
                                width="100%",
                                display="flex",
                                justify_content="center",
                            ),
                            logo(size="md"),
                        ),
                        # Collapse toggle button (desktop only) with tooltip hint
                        rx.box(
                            rx.box(
                                rx.icon(
                                    rx.cond(is_collapsed, "chevrons-right", "chevrons-left"),
                                    size=18,
                                    color=COLORS["text_secondary"],
                                ),
                                on_click=on_toggle_collapse,
                                cursor="pointer",
                                padding="0.5rem",
                                border_radius=RADIUS["lg"],
                                background="transparent",
                                border=f"1.5px solid {COLORS['border_light']}",
                                _hover={
                                    "background": COLORS["primary_green"],
                                    "border_color": COLORS["primary_green"],
                                    "color": COLORS["white"],
                                    "transform": "scale(1.1)",
                                },
                                transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                                title=rx.cond(is_collapsed, "Uitklappen", "Inklappen"),
                            ),
                            display=["none", "none", "flex"],
                        ),
                        spacing="2",
                        align="center",
                        justify="between",
                        width="100%",
                    ),
                    # Search - collapsible icon/input
                    rx.cond(
                        is_collapsed,
                        rx.fragment(),
                        rx.box(
                            rx.cond(
                                AppState.search_expanded,
                                # Expanded search input
                                rx.hstack(
                                    rx.input(
                                        placeholder="Zoek gesprekken...",
                                        value=AppState.search_query,
                                        on_change=AppState.set_search_query,
                                        background=COLORS["white"],
                                        border=f"1.5px solid {COLORS['border_light']}",
                                        border_radius=RADIUS["lg"],
                                        padding="0.625rem 0.875rem",
                                        font_size="0.875rem",
                                        color=COLORS["text_primary"],
                                        width="100%",
                                        auto_focus=True,
                                        _focus={
                                            "border_color": COLORS["primary_green"],
                                            "box_shadow": f"0 0 0 3px {COLORS['primary_green']}20",
                                        },
                                        _placeholder={"color": COLORS["text_tertiary"]},
                                        transition="all 0.2s ease",
                                    ),
                                    rx.icon(
                                        "x",
                                        size=16,
                                        color=COLORS["text_tertiary"],
                                        cursor="pointer",
                                        on_click=AppState.toggle_search,
                                        _hover={"color": COLORS["text_primary"]},
                                    ),
                                    spacing="2",
                                    width="100%",
                                    align="center",
                                ),
                                # Collapsed - just search icon
                                rx.box(
                                    rx.icon(
                                        "search",
                                        size=18,
                                        color=COLORS["text_secondary"],
                                    ),
                                    on_click=AppState.toggle_search,
                                    cursor="pointer",
                                    padding="0.625rem",
                                    border_radius=RADIUS["lg"],
                                    border=f"1.5px solid {COLORS['border_light']}",
                                    background=COLORS["white"],
                                    _hover={
                                        "background": COLORS["light_green"],
                                        "border_color": COLORS["primary_green"],
                                        "transform": "scale(1.05)",
                                    },
                                    transition="all 0.2s ease",
                                    display="flex",
                                    align_items="center",
                                    justify_content="center",
                                ),
                            ),
                            width="100%",
                            margin_top="0.75rem",
                        ),
                    ),
                    spacing="2",
                    width="100%",
                ),
                padding=["1.25rem", "1.25rem", "1.5rem"],
                border_bottom=f"1px solid {COLORS['border_light']}",
                background=f"linear-gradient(135deg, {COLORS['white']} 0%, {COLORS['light_green']}08 100%)",
            ),
            
            # Action buttons
            rx.cond(
                is_collapsed,
                # Collapsed view - icon only
                rx.vstack(
                    rx.box(
                        rx.icon("plus", size=20, color=COLORS["white"]),
                        on_click=on_new_conversation,
                        cursor="pointer",
                        padding="0.875rem",
                        border_radius=RADIUS["xl"],
                        background=f"linear-gradient(135deg, {COLORS['primary_green']} 0%, {COLORS['dark_green']} 100%)",
                        box_shadow=f"0 4px 12px {COLORS['primary_green']}30",
                        _hover={
                            "background": f"linear-gradient(135deg, {COLORS['dark_green']} 0%, {COLORS['primary_green']} 100%)",
                            "transform": "scale(1.08) rotate(90deg)",
                            "box_shadow": f"0 6px 20px {COLORS['primary_green']}40",
                        },
                        transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                        width="100%",
                        display="flex",
                        justify_content="center",
                        align_items="center",
                    ),
                    spacing="2",
                    padding=["1rem", "1rem", "1.25rem"],
                    width="100%",
                ),
                # Expanded view with enhanced button
                rx.vstack(
                    rx.box(
                        rx.hstack(
                            rx.icon("plus", size=18, color=COLORS["white"]),
                            rx.text(
                                "Nieuw gesprek",
                                font_size="0.9375rem",
                                font_weight="600",
                                color=COLORS["white"],
                                letter_spacing="0.02em",
                            ),
                            spacing="2",
                            align="center",
                            justify="center",
                            width="100%",
                        ),
                        on_click=on_new_conversation,
                        cursor="pointer",
                        padding="0.875rem 1.25rem",
                        border_radius=RADIUS["xl"],
                        background=f"linear-gradient(135deg, {COLORS['primary_green']} 0%, {COLORS['dark_green']} 100%)",
                        box_shadow=f"0 4px 12px {COLORS['primary_green']}30, 0 2px 4px rgba(0,0,0,0.1)",
                        _hover={
                            "background": f"linear-gradient(135deg, {COLORS['dark_green']} 0%, {COLORS['primary_green']} 100%)",
                            "transform": "translateY(-2px) scale(1.02)",
                            "box_shadow": f"0 6px 20px {COLORS['primary_green']}40, 0 3px 6px rgba(0,0,0,0.15)",
                        },
                        transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                        width="100%",
                    ),
                    spacing="2",
                    padding=["1rem", "1rem", "1.25rem"],
                    width="100%",
                ),
            ),
            
            # Conversations header (hide when collapsed)
            rx.cond(
                is_collapsed,
                rx.fragment(),
                rx.box(
                    rx.hstack(
                        rx.text(
                            "Gesprekken",
                            font_size="0.8125rem",
                            color=COLORS["text_primary"],
                            font_weight="700",
                            letter_spacing="0.03em",
                        ),
                        rx.box(
                            rx.text(
                                rx.cond(
                                    conversations.length() > 0,
                                    conversations.length().to_string(),
                                    "0",
                                ),
                                font_size="0.75rem",
                                font_weight="600",
                                color=COLORS["text_tertiary"],
                            ),
                            background=f"{COLORS['light_green']}60",
                            padding="0.125rem 0.5rem",
                            border_radius=RADIUS["full"],
                        ),
                        spacing="2",
                        align="center",
                        width="100%",
                    ),
                    padding="0.875rem 1.25rem 0.625rem",
                ),
            ),
            
            # Conversation list (hide when collapsed)
            rx.cond(
                is_collapsed,
                rx.fragment(),
                rx.box(
                    rx.cond(
                        conversations.length() > 0,
                        rx.vstack(
                            rx.foreach(
                                conversations,
                                lambda conv: rx.box(
                                    rx.hstack(
                                        rx.icon(
                                            "message-circle",
                                            size=18,
                                            color=rx.cond(
                                                conv["id"] == current_conversation_id,
                                                COLORS["primary_green"],
                                                COLORS["text_tertiary"]
                                            ),
                                        ),
                                        rx.text(
                                            conv["title"],
                                            font_size="0.875rem",
                                            color=rx.cond(
                                                conv["id"] == current_conversation_id,
                                                COLORS["primary_green"],
                                                COLORS["text_primary"]
                                            ),
                                            font_weight=rx.cond(
                                                conv["id"] == current_conversation_id,
                                                "600",
                                                "500"
                                            ),
                                            white_space="nowrap",
                                            overflow="hidden",
                                            text_overflow="ellipsis",
                                            flex="1",
                                            letter_spacing="-0.01em",
                                        ),
                                        rx.hstack(
                                            rx.box(
                                                rx.icon("archive", size=14, color=COLORS["text_tertiary"]),
                                                on_click=AppState.archive_conversation(conv["id"]),
                                                cursor="pointer",
                                                padding="0.375rem",
                                                border_radius=RADIUS["sm"],
                                                opacity="0",
                                                class_name="conv-action",
                                                background="transparent",
                                                _hover={
                                                    "background": f"linear-gradient(135deg, {COLORS['light_green']} 0%, {COLORS['primary_green']}10 100%)",
                                                    "color": COLORS["primary_green"],
                                                    "transform": "scale(1.1)",
                                                },
                                                transition="all 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
                                            ),
                                            rx.box(
                                                rx.icon("trash-2", size=14, color=COLORS["text_tertiary"]),
                                                on_click=AppState.delete_conversation(conv["id"]),
                                                cursor="pointer",
                                                padding="0.375rem",
                                                border_radius=RADIUS["sm"],
                                                opacity="0",
                                                class_name="conv-action",
                                                background="transparent",
                                                _hover={
                                                    "background": f"linear-gradient(135deg, {COLORS['error']}15 0%, {COLORS['error']}25 100%)",
                                                    "color": COLORS["error"],
                                                    "transform": "scale(1.1)",
                                                },
                                                transition="all 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
                                            ),
                                            spacing="1",
                                            flex_shrink="0",
                                        ),
                                        spacing="3",
                                        align="center",
                                        width="100%",
                                        justify="start",
                                    ),
                                    background=rx.cond(
                                        conv["id"] == current_conversation_id,
                                        f"linear-gradient(135deg, {COLORS['light_green']} 0%, {COLORS['light_green']}80 100%)",
                                        "transparent"
                                    ),
                                    border_radius=RADIUS["lg"],
                                    padding="0.875rem 1rem",
                                    margin="0 0.75rem",
                                    cursor="pointer",
                                    on_click=AppState.load_conversation(conv["id"]),
                                    border_left=rx.cond(
                                        conv["id"] == current_conversation_id,
                                        f"3px solid {COLORS['primary_green']}",
                                        "3px solid transparent"
                                    ),
                                    box_shadow=rx.cond(
                                        conv["id"] == current_conversation_id,
                                        f"0 4px 12px {COLORS['primary_green']}15",
                                        "none"
                                    ),
                                    _hover={
                                        "background": rx.cond(
                                            conv["id"] == current_conversation_id,
                                            f"linear-gradient(135deg, {COLORS['light_green']} 0%, {COLORS['light_green']}90 100%)",
                                            f"linear-gradient(135deg, {COLORS['hover_bg']} 0%, {COLORS['light_gray']}40 100%)"
                                        ),
                                        "transform": "translateX(4px)",
                                        "box_shadow": f"0 4px 12px {COLORS['primary_green']}20",
                                        ".conv-action": {"opacity": "1"},
                                    },
                                    transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                                ),
                            ),
                            spacing="1",
                            width="100%",
                        ),
                        # Enhanced empty state
                        rx.vstack(
                            rx.box(
                                rx.icon(
                                    "message-circle-plus",
                                    size=48,
                                    color=f"{COLORS['primary_green']}40",
                                ),
                                padding="1rem",
                                background=f"{COLORS['light_green']}30",
                                border_radius=RADIUS["full"],
                                margin_bottom="1rem",
                            ),
                            rx.text(
                                "Nog geen gesprekken",
                                font_size="0.9375rem",
                                font_weight="600",
                                color=COLORS["text_primary"],
                                text_align="center",
                            ),
                            rx.text(
                                "Start een nieuw gesprek om te beginnen met chatten!",
                                font_size="0.8125rem",
                                color=COLORS["text_secondary"],
                                text_align="center",
                                line_height="1.5",
                                max_width="200px",
                            ),
                            spacing="2",
                            align="center",
                            padding="3rem 1.5rem",
                        ),
                    ),
                    flex="1",
                    overflow_y="auto",
                    width="100%",
                ),
            ),
            
            # Onboarding link section with improved styling
            rx.box(
                rx.link(
                    rx.cond(
                        is_collapsed,
                        rx.box(
                            rx.icon("sparkles", size=20, color=COLORS["primary_green"]),
                            display="flex",
                            justify_content="center",
                            width="100%",
                        ),
                        rx.hstack(
                            rx.box(
                                rx.icon("sparkles", size=16, color=COLORS["primary_green"]),
                                background=f"{COLORS['light_green']}80",
                                padding="0.5rem",
                                border_radius=RADIUS["md"],
                            ),
                            rx.vstack(
                                rx.text(
                                    "Personaliseer je ervaring",
                                    font_size="0.875rem",
                                    font_weight="600",
                                    color=COLORS["text_primary"],
                                    line_height="1.3",
                                ),
                                rx.text(
                                    "Start onboarding",
                                    font_size="0.75rem",
                                    color=COLORS["primary_green"],
                                    line_height="1.3",
                                ),
                                spacing="0",
                                align_items="start",
                                flex="1",
                            ),
                            rx.icon("arrow-right", size=16, color=COLORS["text_tertiary"]),
                            spacing="3",
                            align="center",
                            width="100%",
                        ),
                    ),
                    href="/onboarding",
                    text_decoration="none",
                ),
                padding=rx.cond(is_collapsed, "0.875rem", "1rem 1.25rem"),
                border_top=f"1px solid {COLORS['border_light']}",
                border_bottom=f"1px solid {COLORS['border_light']}",
                cursor="pointer",
                background="transparent",
                _hover={
                    "background": f"{COLORS['light_green']}40",
                    "border_color": f"{COLORS['primary_green']}30",
                },
                transition="all 0.25s cubic-bezier(0.4, 0, 0.2, 1)",
                width="100%",
            ),
            
            # User profile section with enhanced design
            rx.box(
                rx.cond(
                    is_collapsed,
                    # Collapsed view - avatar only
                    rx.vstack(
                        avatar(name=user_name, size="md"),
                        rx.box(
                            rx.icon("settings", size=16, color=COLORS["text_secondary"]),
                            cursor="pointer",
                            padding="0.5rem",
                            border_radius=RADIUS["lg"],
                            border=f"1.5px solid {COLORS['border_light']}",
                            _hover={
                                "background": COLORS["primary_green"],
                                "color": COLORS["white"],
                                "border_color": COLORS["primary_green"],
                                "transform": "rotate(45deg) scale(1.1)",
                            },
                            transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                        ),
                        spacing="2",
                        align="center",
                        width="100%",
                    ),
                    # Expanded view with better layout
                    rx.hstack(
                        avatar(name=user_name, size="md"),
                        rx.vstack(
                            rx.text(
                                user_name,
                                font_size="0.9375rem",
                                font_weight="600",
                                color=COLORS["text_primary"],
                                line_height="1.3",
                                white_space="nowrap",
                                overflow="hidden",
                                text_overflow="ellipsis",
                            ),
                            rx.text(
                                user_email,
                                font_size="0.75rem",
                                color=COLORS["text_secondary"],
                                line_height="1.3",
                                white_space="nowrap",
                                overflow="hidden",
                                text_overflow="ellipsis",
                            ),
                            spacing="1",
                            align_items="start",
                            flex="1",
                            min_width="0",
                        ),
                        rx.box(
                            rx.icon("settings", size=16, color=COLORS["text_secondary"]),
                            cursor="pointer",
                            padding="0.625rem",
                            border_radius=RADIUS["lg"],
                            border=f"1.5px solid {COLORS['border_light']}",
                            flex_shrink="0",
                            _hover={
                                "background": COLORS["primary_green"],
                                "color": COLORS["white"],
                                "border_color": COLORS["primary_green"],
                                "transform": "rotate(45deg) scale(1.1)",
                            },
                            transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                        ),
                        spacing="3",
                        align="center",
                        justify="between",
                        width="100%",
                    ),
                ),
                padding=["1.125rem 1rem", "1.125rem 1rem", "1.25rem 1.25rem"],
                width="100%",
                background=f"linear-gradient(135deg, {COLORS['white']} 0%, {COLORS['light_green']}05 100%)",
                border_top=f"1px solid {COLORS['border_light']}",
            ),
            
            spacing="0",
            height="100vh",
            width="100%",
        ),
        # Modern responsive styling with collapse animation
        width=rx.cond(
            is_collapsed,
            ["280px", "280px", "70px"],  # Collapsed: narrow icon-only width on desktop
            ["280px", "280px", "300px"]  # Expanded: slightly wider for better readability
        ),
        background=f"linear-gradient(180deg, {COLORS['white']} 0%, {COLORS['light_green']}03 50%, {COLORS['white']} 100%)",
        border_right=f"1.5px solid {COLORS['border_light']}",
        height="100vh",
        position="fixed",
        top="0",
        overflow_y="auto",
        overflow_x="hidden",
        flex_shrink="0",
        # Mobile: slide in/out based on is_open, above overlay
        left=rx.cond(is_open, "0", "-100%"),
        z_index=["1001", "1001", "auto"],
        transition="all 0.35s cubic-bezier(0.4, 0, 0.2, 1)",
        box_shadow=rx.cond(
            is_open,
            "0 10px 40px rgba(0,0,0,0.15), 0 4px 12px rgba(0,0,0,0.1)",
            "none"
        ),
        backdrop_filter="blur(10px)",
        
        # Custom scrollbar styling
        **{
            "&::-webkit-scrollbar": {
                "width": "6px",
            },
            "&::-webkit-scrollbar-track": {
                "background": "transparent",
            },
            "&::-webkit-scrollbar-thumb": {
                "background": f"{COLORS['primary_green']}30",
                "border-radius": "3px",
            },
            "&::-webkit-scrollbar-thumb:hover": {
                "background": f"{COLORS['primary_green']}50",
            },
            # Desktop: always visible
            "@media (min-width: 1024px)": {
                "left": "0 !important",
                "position": "relative",
                "box_shadow": "0 0 1px rgba(0,0,0,0.06), 0 4px 20px rgba(0,0,0,0.05)",
            }
        }
    )
