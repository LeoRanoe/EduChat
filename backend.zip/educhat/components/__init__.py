"""UI components for EduChat."""

