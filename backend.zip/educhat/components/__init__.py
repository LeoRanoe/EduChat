"""UI components for EduChat."""
