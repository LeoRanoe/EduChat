"""Styling and theme configuration."""
