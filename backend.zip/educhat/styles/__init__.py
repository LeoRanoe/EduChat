"""Styling and theme configuration."""

