"""Services for external integrations (Supabase/Postgres, OpenAI, etc.)."""
