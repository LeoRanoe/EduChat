"""Main application entry point for EduChat."""

import reflex as rx
from educhat.pages import index
from educhat.pages.onboarding import onboarding
from educhat.pages.landing import landing
from educhat.styles.theme import COLORS


# Create the app instance with theme configuration
# Using Reflex's built-in color mode system with next-themes
app = rx.App(
    stylesheets=[
        "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap",
        "/landing-animations.css",
    ],
    style={
        "font_family": "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        "background": "var(--bg-primary)",  # Use CSS variable for theme-aware background
    },
    theme=rx.theme(
        appearance="inherit",  # "inherit" respects system preference + user toggle
        accent_color="green",
    ),
)

# Add pages
app.add_page(
    landing,
    route="/",
    title="EduChat - Your AI Study Assistant",
    description="Get instant help with your studies, homework, and exam preparation",
)
app.add_page(
    index,
    route="/chat",
    title="Chat - EduChat",
    description="EduChat helpt je makkelijk informatie te vinden over onderwijs in Suriname",
)
app.add_page(
    onboarding,
    route="/onboarding",
    title="Onboarding - EduChat",
    description="Personaliseer je EduChat ervaring",
)

