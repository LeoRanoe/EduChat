"""EduChat - AI-powered educational assistant for Surinamese students."""

__version__ = "0.1.0"
