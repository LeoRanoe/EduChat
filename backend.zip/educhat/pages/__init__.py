"""Pages for EduChat application."""

from educhat.pages.index import index

__all__ = ["index"]
