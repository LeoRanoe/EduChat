2025-11-14T11:04:00.347579249Z   post_request: <function PostRequest.post_request at 0x72ebd6f70b80>
2025-11-14T11:04:00.34758184Z   child_exit: <function ChildExit.child_exit at 0x72ebd6f70cc0>
2025-11-14T11:04:00.34758452Z   worker_exit: <function WorkerExit.worker_exit at 0x72ebd6f70e00>
2025-11-14T11:04:00.34758762Z   nworkers_changed: <function NumWorkersChanged.nworkers_changed at 0x72ebd6f70f40>
2025-11-14T11:04:00.34759544Z   on_exit: <function OnExit.on_exit at 0x72ebd6f71080>
2025-11-14T11:04:00.34759816Z   ssl_context: <function NewSSLContext.ssl_context at 0x72ebd6f71260>
2025-11-14T11:04:00.34760075Z   proxy_protocol: False
2025-11-14T11:04:00.34760334Z   proxy_allow_ips: ['127.0.0.1', '::1']
2025-11-14T11:04:00.34760574Z   keyfile: None
2025-11-14T11:04:00.3476082Z   certfile: None
2025-11-14T11:04:00.34761064Z   ssl_version: 2
2025-11-14T11:04:00.347613221Z   cert_reqs: 0
2025-11-14T11:04:00.34761567Z   ca_certs: None
2025-11-14T11:04:00.347618221Z   suppress_ragged_eofs: True
2025-11-14T11:04:00.347620681Z   do_handshake_on_connect: False
2025-11-14T11:04:00.347623321Z   ciphers: None
2025-11-14T11:04:00.347625921Z   raw_paste_global_conf: []
2025-11-14T11:04:00.347628561Z   permit_obsolete_folding: False
2025-11-14T11:04:00.347631251Z   strip_header_spaces: False
2025-11-14T11:04:00.347649531Z   permit_unconventional_http_method: False
2025-11-14T11:04:00.347652542Z   permit_unconventional_http_version: False
2025-11-14T11:04:00.347655131Z   casefold_http_method: False
2025-11-14T11:04:00.347657642Z   forwarder_headers: ['SCRIPT_NAME', 'PATH_INFO']
2025-11-14T11:04:00.347660122Z   header_map: drop
2025-11-14T11:04:17.304816665Z Warning: `reflex.plugins.sitemap.SitemapPlugin` plugin is enabled by default, 
2025-11-14T11:04:17.304845866Z but not explicitly added to the config. If you want to use it, please add it to 
2025-11-14T11:04:17.304851426Z the `plugins` list in your config inside of `rxconfig.py`. To disable this 
2025-11-14T11:04:17.304856256Z plugin, set `disable_plugins` to `['reflex.plugins.sitemap.SitemapPlugin']`.
2025-11-14T11:04:18.40378283Z Warning: `reflex.plugins.sitemap.SitemapPlugin` plugin is enabled by default, 
2025-11-14T11:04:18.403803761Z but not explicitly added to the config. If you want to use it, please add it to 
2025-11-14T11:04:18.403808331Z the `plugins` list in your config inside of `rxconfig.py`. To disable this 
2025-11-14T11:04:18.403812601Z plugin, set `disable_plugins` to `['reflex.plugins.sitemap.SitemapPlugin']`.
2025-11-14T11:04:18.50127472Z [2025-11-14 11:04:18 +0000] [44] [INFO] Starting gunicorn 23.0.0
2025-11-14T11:04:18.501866985Z [2025-11-14 11:04:18 +0000] [44] [ERROR] Connection in use: ('0.0.0.0', 10000)
2025-11-14T11:04:18.501885056Z [2025-11-14 11:04:18 +0000] [44] [ERROR] connection to ('0.0.0.0', 10000) failed: [Errno 98] Address already in use
2025-11-14T11:04:18.501938797Z [2025-11-14 11:04:18 +0000] [44] [DEBUG] Retrying in 1 second.
2025-11-14T11:04:19.502477869Z [2025-11-14 11:04:19 +0000] [44] [ERROR] Connection in use: ('0.0.0.0', 10000)
2025-11-14T11:04:19.50250023Z [2025-11-14 11:04:19 +0000] [44] [ERROR] connection to ('0.0.0.0', 10000) failed: [Errno 98] Address already in use
2025-11-14T11:04:19.50252275Z [2025-11-14 11:04:19 +0000] [44] [DEBUG] Retrying in 1 second.
2025-11-14T11:04:20.503049972Z [2025-11-14 11:04:20 +0000] [44] [ERROR] Connection in use: ('0.0.0.0', 10000)
2025-11-14T11:04:20.503080623Z [2025-11-14 11:04:20 +0000] [44] [ERROR] connection to ('0.0.0.0', 10000) failed: [Errno 98] Address already in use
2025-11-14T11:04:20.503150444Z [2025-11-14 11:04:20 +0000] [44] [DEBUG] Retrying in 1 second.
2025-11-14T11:04:21.503634965Z [2025-11-14 11:04:21 +0000] [44] [ERROR] Connection in use: ('0.0.0.0', 10000)
2025-11-14T11:04:21.503667546Z [2025-11-14 11:04:21 +0000] [44] [ERROR] connection to ('0.0.0.0', 10000) failed: [Errno 98] Address already in use
2025-11-14T11:04:21.503707497Z [2025-11-14 11:04:21 +0000] [44] [DEBUG] Retrying in 1 second.
2025-11-14T11:04:22.504205958Z [2025-11-14 11:04:22 +0000] [44] [ERROR] Connection in use: ('0.0.0.0', 10000)
2025-11-14T11:04:22.504240189Z [2025-11-14 11:04:22 +0000] [44] [ERROR] connection to ('0.0.0.0', 10000) failed: [Errno 98] Address already in use
2025-11-14T11:04:22.504249669Z [2025-11-14 11:04:22 +0000] [44] [DEBUG] Retrying in 1 second.
2025-11-14T11:04:23.504649207Z [2025-11-14 11:04:23 +0000] [44] [ERROR] Can't connect to ('0.0.0.0', 10000)
2025-11-14T11:04:26.7931623Z [11:04:26] Reflex app stopped.                                    console.py:231