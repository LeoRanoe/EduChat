-- EduChat Complete Database Schema Migration
-- Run this in Supabase SQL Editor to create ALL tables for the full feature set
-- This extends the admin_schema.sql with remaining tables

-- ============================================================
-- WEB SCRAPER TABLES
-- ============================================================

-- Scraper Jobs table
CREATE TABLE IF NOT EXISTS scraper_jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR NOT NULL,
    description TEXT,
    target_url VARCHAR NOT NULL,
    scraper_type VARCHAR NOT NULL CHECK (scraper_type IN ('institution', 'study', 'event', 'deadline', 'general')),
    schedule_cron VARCHAR,
    selectors JSONB NOT NULL DEFAULT '{}',
    data_mapping JSONB NOT NULL DEFAULT '{}',
    headers JSONB,
    auth_config JSONB,
    status VARCHAR DEFAULT 'idle' CHECK (status IN ('idle', 'running', 'paused', 'error', 'completed')),
    is_active BOOLEAN DEFAULT TRUE,
    last_run_at TIMESTAMP WITH TIME ZONE,
    next_run_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES auth.users(id)
);

CREATE INDEX IF NOT EXISTS idx_scraper_jobs_status ON scraper_jobs(status);
CREATE INDEX IF NOT EXISTS idx_scraper_jobs_type ON scraper_jobs(scraper_type);

-- Scraper Run History
CREATE TABLE IF NOT EXISTS scraper_runs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL REFERENCES scraper_jobs(id) ON DELETE CASCADE,
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    status VARCHAR NOT NULL CHECK (status IN ('running', 'success', 'failed', 'partial', 'cancelled')),
    items_found INTEGER DEFAULT 0,
    items_created INTEGER DEFAULT 0,
    items_updated INTEGER DEFAULT 0,
    items_failed INTEGER DEFAULT 0,
    error_log TEXT,
    run_log JSONB,
    triggered_by VARCHAR CHECK (triggered_by IN ('manual', 'scheduled', 'api'))
);

CREATE INDEX IF NOT EXISTS idx_scraper_runs_job_id ON scraper_runs(job_id);
CREATE INDEX IF NOT EXISTS idx_scraper_runs_status ON scraper_runs(status);

-- Scraper Instructions
CREATE TABLE IF NOT EXISTS scraper_instructions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL REFERENCES scraper_jobs(id) ON DELETE CASCADE,
    instruction_type VARCHAR NOT NULL CHECK (instruction_type IN ('include', 'exclude', 'transform', 'validate', 'clean')),
    rule JSONB NOT NULL,
    priority INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_scraper_instructions_job_id ON scraper_instructions(job_id);

-- ============================================================
-- EMAIL SERVICE TABLES
-- ============================================================

-- Email Templates table
CREATE TABLE IF NOT EXISTS email_templates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR NOT NULL UNIQUE,
    subject VARCHAR NOT NULL,
    body_html TEXT NOT NULL,
    body_text TEXT,
    template_type VARCHAR NOT NULL CHECK (template_type IN ('transactional', 'notification', 'reminder', 'marketing', 'system')),
    variables JSONB,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES auth.users(id)
);

CREATE INDEX IF NOT EXISTS idx_email_templates_name ON email_templates(name);
CREATE INDEX IF NOT EXISTS idx_email_templates_type ON email_templates(template_type);

-- Email Queue table
CREATE TABLE IF NOT EXISTS email_queue (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    template_id UUID REFERENCES email_templates(id),
    to_email VARCHAR NOT NULL,
    to_name VARCHAR,
    subject VARCHAR NOT NULL,
    body_html TEXT NOT NULL,
    body_text TEXT,
    variables JSONB,
    status VARCHAR DEFAULT 'pending' CHECK (status IN ('pending', 'sending', 'sent', 'failed', 'bounced', 'cancelled')),
    priority INTEGER DEFAULT 5,
    scheduled_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    sent_at TIMESTAMP WITH TIME ZONE,
    attempts INTEGER DEFAULT 0,
    max_attempts INTEGER DEFAULT 3,
    error_message TEXT,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_email_queue_status ON email_queue(status);
CREATE INDEX IF NOT EXISTS idx_email_queue_scheduled_at ON email_queue(scheduled_at);

-- Email Logs table
CREATE TABLE IF NOT EXISTS email_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    queue_id UUID REFERENCES email_queue(id),
    event_type VARCHAR NOT NULL CHECK (event_type IN ('sent', 'delivered', 'opened', 'clicked', 'bounced', 'complained', 'failed')),
    event_data JSONB,
    occurred_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_email_logs_queue_id ON email_logs(queue_id);

-- ============================================================
-- CONTENT MANAGEMENT TABLES
-- ============================================================

-- FAQ table
CREATE TABLE IF NOT EXISTS faqs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    category VARCHAR,
    keywords TEXT[],
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    view_count INTEGER DEFAULT 0,
    helpful_count INTEGER DEFAULT 0,
    not_helpful_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES auth.users(id)
);

CREATE INDEX IF NOT EXISTS idx_faqs_category ON faqs(category);
CREATE INDEX IF NOT EXISTS idx_faqs_is_active ON faqs(is_active);

-- Knowledge Base Articles
CREATE TABLE IF NOT EXISTS knowledge_articles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR NOT NULL,
    slug VARCHAR UNIQUE NOT NULL,
    content TEXT NOT NULL,
    summary TEXT,
    category VARCHAR,
    tags TEXT[],
    status VARCHAR DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
    author_id UUID REFERENCES auth.users(id),
    view_count INTEGER DEFAULT 0,
    published_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_knowledge_articles_slug ON knowledge_articles(slug);
CREATE INDEX IF NOT EXISTS idx_knowledge_articles_status ON knowledge_articles(status);

-- ============================================================
-- INSERT DEFAULT EMAIL TEMPLATES
-- ============================================================

INSERT INTO email_templates (name, subject, body_html, body_text, template_type, variables) VALUES
(
    'welcome',
    'Welkom bij EduChat! 🎓',
    '<h1>Welkom bij EduChat, {{user_name}}!</h1><p>We zijn blij dat je je hebt aangemeld. EduChat helpt je met al je vragen over het Surinaams onderwijs.</p><p>Heb je vragen? Start een chat op <a href="{{app_url}}">EduChat</a>.</p>',
    'Welkom bij EduChat, {{user_name}}! We zijn blij dat je je hebt aangemeld.',
    'transactional',
    '["user_name", "app_url"]'
),
(
    'password_reset',
    'Wachtwoord resetten - EduChat',
    '<h1>Wachtwoord resetten</h1><p>Hallo {{user_name}},</p><p>Klik op de link hieronder om je wachtwoord te resetten:</p><p><a href="{{reset_link}}">Wachtwoord resetten</a></p><p>Deze link is 24 uur geldig.</p>',
    'Hallo {{user_name}}, Klik op deze link om je wachtwoord te resetten: {{reset_link}}',
    'transactional',
    '["user_name", "reset_link"]'
),
(
    'event_reminder',
    'Herinnering: {{event_title}} morgen!',
    '<h1>Herinnering</h1><p>Hallo {{user_name}},</p><p>Dit is een herinnering dat <strong>{{event_title}}</strong> morgen plaatsvindt op {{event_date}}.</p><p>Vergeet het niet!</p>',
    'Herinnering: {{event_title}} vindt morgen plaats op {{event_date}}.',
    'reminder',
    '["user_name", "event_title", "event_date"]'
),
(
    'deadline_reminder',
    '⚠️ Deadline nadert: {{deadline_title}}',
    '<h1>Deadline Herinnering</h1><p>Hallo {{user_name}},</p><p>De deadline voor <strong>{{deadline_title}}</strong> is over {{days_remaining}} dagen ({{deadline_date}}).</p><p>Zorg dat je op tijd bent!</p>',
    'Deadline herinnering: {{deadline_title}} is over {{days_remaining}} dagen.',
    'reminder',
    '["user_name", "deadline_title", "deadline_date", "days_remaining"]'
)
ON CONFLICT (name) DO NOTHING;

-- ============================================================
-- INSERT DEFAULT FAQ ENTRIES
-- ============================================================

INSERT INTO faqs (question, answer, category, keywords, display_order, is_active) VALUES
(
    'Hoe kan ik me inschrijven bij de AdeKUS?',
    'Om je in te schrijven bij de Anton de Kom Universiteit van Suriname (AdeKUS), moet je: 1) Een aanmeldingsformulier invullen op de website, 2) Je VWO/HAVO diploma inleveren, 3) De inschrijfkosten betalen, 4) Wachten op goedkeuring. Bezoek www.uvs.edu voor meer informatie.',
    'Inschrijving',
    ARRAY['adekus', 'inschrijven', 'universiteit', 'aanmelden'],
    1,
    true
),
(
    'Wat zijn de toelatingseisen voor de universiteit?',
    'De toelatingseisen variëren per opleiding. Over het algemeen heb je nodig: VWO diploma of gelijkwaardig, specifieke vakken afhankelijk van de studierichting, en soms een toelatingsexamen. Neem contact op met de specifieke faculteit voor exacte eisen.',
    'Toelating',
    ARRAY['toelating', 'eisen', 'diploma', 'vwo'],
    2,
    true
),
(
    'Wanneer beginnen de inschrijvingen?',
    'De inschrijvingsperiode voor de meeste onderwijsinstellingen in Suriname loopt van januari tot maart voor het nieuwe schooljaar. Sommige instellingen hebben ook een tweede inschrijfperiode in augustus. Check de website van de instelling voor exacte data.',
    'Deadlines',
    ARRAY['inschrijving', 'deadline', 'wanneer', 'periode'],
    3,
    true
),
(
    'Hoeveel kost een studie in Suriname?',
    'Studiekosten variëren per instelling en opleiding. Bij de AdeKUS zijn de kosten relatief laag (enkele honderden SRD per semester). Particuliere instellingen kunnen duurder zijn. Informeer bij de specifieke instelling naar actuele tarieven en eventuele beursmogelijkheden.',
    'Kosten',
    ARRAY['kosten', 'prijs', 'collegegeld', 'betalen'],
    4,
    true
)
ON CONFLICT DO NOTHING;

-- ============================================================
-- ENABLE RLS ON NEW TABLES
-- ============================================================

ALTER TABLE scraper_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE scraper_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE scraper_instructions ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE faqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE knowledge_articles ENABLE ROW LEVEL SECURITY;

-- Public can read active FAQs
CREATE POLICY "Public can read active FAQs" ON faqs
    FOR SELECT USING (is_active = true);

-- Public can read published articles
CREATE POLICY "Public can read published articles" ON knowledge_articles
    FOR SELECT USING (status = 'published');

-- Success message
DO $$
BEGIN
    RAISE NOTICE 'Complete schema migration successful!';
    RAISE NOTICE 'New tables: scraper_jobs, scraper_runs, scraper_instructions, email_templates, email_queue, email_logs, faqs, knowledge_articles';
END $$;
