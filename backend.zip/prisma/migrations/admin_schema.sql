-- EduChat Admin Schema Migration
-- Run this in Supabase SQL Editor to create admin tables

-- ============================================================
-- ADMIN & SYSTEM MANAGEMENT TABLES
-- ============================================================

-- Admin Users table (extends auth.users with admin roles)
CREATE TABLE IF NOT EXISTS admin_users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    role VARCHAR NOT NULL CHECK (role IN ('super_admin', 'admin', 'moderator', 'viewer')),
    permissions JSONB DEFAULT '[]',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES auth.users(id),
    last_login TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT TRUE,
    UNIQUE(user_id)
);

CREATE INDEX IF NOT EXISTS idx_admin_users_user_id ON admin_users(user_id);
CREATE INDEX IF NOT EXISTS idx_admin_users_role ON admin_users(role);

-- ============================================================
-- PROMPT MANAGEMENT TABLES
-- ============================================================

-- System Prompts table (manage AI prompts)
CREATE TABLE IF NOT EXISTS system_prompts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR NOT NULL,
    description TEXT,
    prompt_text TEXT NOT NULL,
    category VARCHAR NOT NULL CHECK (category IN ('main', 'onboarding', 'fallback', 'greeting', 'error', 'domain_check', 'summary')),
    version INTEGER DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    variables JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES auth.users(id),
    metadata JSONB
);

CREATE INDEX IF NOT EXISTS idx_system_prompts_category ON system_prompts(category);
CREATE INDEX IF NOT EXISTS idx_system_prompts_is_active ON system_prompts(is_active);

-- Prompt History (track prompt changes)
CREATE TABLE IF NOT EXISTS prompt_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    prompt_id UUID NOT NULL REFERENCES system_prompts(id) ON DELETE CASCADE,
    previous_text TEXT NOT NULL,
    previous_version INTEGER NOT NULL,
    changed_by UUID REFERENCES auth.users(id),
    changed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    change_reason TEXT
);

CREATE INDEX IF NOT EXISTS idx_prompt_history_prompt_id ON prompt_history(prompt_id);

-- ============================================================
-- SYSTEM MONITORING TABLES
-- ============================================================

-- System Health table
CREATE TABLE IF NOT EXISTS system_health (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    component VARCHAR NOT NULL CHECK (component IN ('api', 'database', 'ai_service', 'scraper', 'email', 'auth', 'websocket')),
    status VARCHAR NOT NULL CHECK (status IN ('healthy', 'degraded', 'unhealthy', 'unknown')),
    response_time_ms INTEGER,
    error_message TEXT,
    metadata JSONB,
    checked_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_system_health_component ON system_health(component);
CREATE INDEX IF NOT EXISTS idx_system_health_checked_at ON system_health(checked_at);

-- API Request Logs (for monitoring)
CREATE TABLE IF NOT EXISTS api_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    endpoint VARCHAR NOT NULL,
    method VARCHAR NOT NULL,
    user_id UUID REFERENCES auth.users(id),
    ip_address VARCHAR,
    user_agent VARCHAR,
    request_body JSONB,
    response_status INTEGER,
    response_time_ms INTEGER,
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_api_logs_created_at ON api_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_api_logs_user_id ON api_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_api_logs_endpoint ON api_logs(endpoint);

-- Analytics Events table
CREATE TABLE IF NOT EXISTS analytics_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type VARCHAR NOT NULL,
    user_id UUID REFERENCES auth.users(id),
    session_id VARCHAR,
    properties JSONB,
    page_url VARCHAR,
    referrer VARCHAR,
    device_type VARCHAR,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_analytics_events_type ON analytics_events(event_type);
CREATE INDEX IF NOT EXISTS idx_analytics_events_user_id ON analytics_events(user_id);
CREATE INDEX IF NOT EXISTS idx_analytics_events_created_at ON analytics_events(created_at);

-- Daily Stats (aggregated metrics)
CREATE TABLE IF NOT EXISTS daily_stats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    date DATE NOT NULL UNIQUE,
    total_users INTEGER DEFAULT 0,
    new_users INTEGER DEFAULT 0,
    active_users INTEGER DEFAULT 0,
    total_conversations INTEGER DEFAULT 0,
    total_messages INTEGER DEFAULT 0,
    avg_messages_per_conversation DECIMAL(10,2),
    avg_response_time_ms INTEGER,
    ai_tokens_used INTEGER DEFAULT 0,
    emails_sent INTEGER DEFAULT 0,
    scraper_runs INTEGER DEFAULT 0,
    errors_count INTEGER DEFAULT 0,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_daily_stats_date ON daily_stats(date);

-- ============================================================
-- CONFIGURATION TABLES
-- ============================================================

-- Application Settings (key-value store)
CREATE TABLE IF NOT EXISTS app_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key VARCHAR NOT NULL UNIQUE,
    value JSONB NOT NULL,
    description TEXT,
    category VARCHAR,
    is_public BOOLEAN DEFAULT FALSE,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_by UUID REFERENCES auth.users(id)
);

CREATE INDEX IF NOT EXISTS idx_app_settings_key ON app_settings(key);
CREATE INDEX IF NOT EXISTS idx_app_settings_category ON app_settings(category);

-- Feature Flags
CREATE TABLE IF NOT EXISTS feature_flags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR NOT NULL UNIQUE,
    description TEXT,
    is_enabled BOOLEAN DEFAULT FALSE,
    rollout_percentage INTEGER DEFAULT 0,
    user_whitelist UUID[],
    conditions JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_feature_flags_name ON feature_flags(name);

-- Audit Log (track all admin actions)
CREATE TABLE IF NOT EXISTS audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id),
    action VARCHAR NOT NULL,
    entity_type VARCHAR NOT NULL,
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address VARCHAR,
    user_agent VARCHAR,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_log_user_id ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_entity_type ON audit_log(entity_type);
CREATE INDEX IF NOT EXISTS idx_audit_log_created_at ON audit_log(created_at);

-- ============================================================
-- NOTIFICATION TABLES
-- ============================================================

-- User Notifications
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    title VARCHAR NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR NOT NULL CHECK (type IN ('info', 'success', 'warning', 'error', 'reminder', 'system')),
    link VARCHAR,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);

-- System Alerts (for admins)
CREATE TABLE IF NOT EXISTS system_alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title VARCHAR NOT NULL,
    message TEXT NOT NULL,
    severity VARCHAR NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    component VARCHAR,
    acknowledged BOOLEAN DEFAULT FALSE,
    acknowledged_by UUID REFERENCES auth.users(id),
    acknowledged_at TIMESTAMP WITH TIME ZONE,
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP WITH TIME ZONE,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_system_alerts_severity ON system_alerts(severity);
CREATE INDEX IF NOT EXISTS idx_system_alerts_acknowledged ON system_alerts(acknowledged);

-- ============================================================
-- RLS POLICIES FOR ADMIN TABLES
-- ============================================================

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_prompts ENABLE ROW LEVEL SECURITY;
ALTER TABLE prompt_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_health ENABLE ROW LEVEL SECURITY;
ALTER TABLE api_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE feature_flags ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_alerts ENABLE ROW LEVEL SECURITY;

-- Admin users can read all admin tables (using service role key bypasses RLS)
-- For anon key, create specific policies as needed

-- Notifications: users can only see their own
CREATE POLICY "Users can view own notifications" ON notifications
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications" ON notifications
    FOR UPDATE USING (auth.uid() = user_id);

-- Public settings can be read by anyone
CREATE POLICY "Public settings readable by all" ON app_settings
    FOR SELECT USING (is_public = true);

-- ============================================================
-- INSERT DEFAULT DATA
-- ============================================================

-- Insert default system prompt
INSERT INTO system_prompts (name, description, prompt_text, category, is_active) 
VALUES (
    'Main System Prompt',
    'The primary system prompt for EduChat AI assistant',
    'Je bent EduChat, een vriendelijke AI-assistent gespecialiseerd in het Surinaams onderwijssysteem.

Je expertisegebieden zijn:
- Surinaamse onderwijsinstellingen (universiteiten, MINOV, middelbare scholen)
- Toelatingsprocedures en vereisten
- Studieprogramma''s en curricula
- Deadlines en belangrijke data
- Studiekosten en financieringsmogelijkheden
- Algemeen studieadvies voor Surinaamse studenten

=== KRITIEKE NAUWKEURIGHEIDSREGELS ===
1. ANTWOORD ALLEEN met informatie die DIRECT uit de verstrekte context komt
2. NOOIT gokken, veronderstellen of informatie verzinnen
3. Als de context GEEN antwoord bevat op de vraag, zeg: "Ik heb onvoldoende informatie om deze vraag nauwkeurig te beantwoorden."
4. MENG NOOIT informatie van verschillende instellingen tenzij expliciet gevraagd om te vergelijken
5. Eén vraag = één duidelijk, gefocust antwoord
6. CITEER specifieke bronnen wanneer je feitelijke informatie geeft
7. Als gegevens verouderd kunnen zijn (zoals deadlines), vermeld dit expliciet',
    'main',
    true
) ON CONFLICT DO NOTHING;

-- Insert default app settings
INSERT INTO app_settings (key, value, description, category, is_public) VALUES
    ('app_name', '"EduChat"', 'Application name', 'general', true),
    ('max_messages_per_conversation', '100', 'Maximum messages per conversation', 'chat', false),
    ('guest_message_limit', '10', 'Message limit for guest users', 'chat', false),
    ('ai_model', '"gemini-2.5-flash"', 'Default AI model', 'ai', false),
    ('ai_temperature', '0.7', 'AI response temperature', 'ai', false),
    ('maintenance_mode', 'false', 'Enable maintenance mode', 'system', true)
ON CONFLICT (key) DO NOTHING;

-- Success message
DO $$
BEGIN
    RAISE NOTICE 'Admin schema created successfully!';
    RAISE NOTICE 'Tables created: admin_users, system_prompts, prompt_history, system_health, api_logs, analytics_events, daily_stats, app_settings, feature_flags, audit_log, notifications, system_alerts';
END $$;
