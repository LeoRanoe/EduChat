-- ============================================================
-- ROLLBACK SCRIPT - Remove all Admin Dashboard Tables
-- ============================================================
-- Run this in Supabase SQL Editor to remove all admin-related tables
-- and revert to the base EduChat schema

-- Drop all admin tables (in correct order due to foreign keys)
DROP TABLE IF EXISTS public.system_alerts CASCADE;
DROP TABLE IF EXISTS public.notifications CASCADE;
DROP TABLE IF EXISTS public.audit_log CASCADE;
DROP TABLE IF EXISTS public.feature_flags CASCADE;
DROP TABLE IF EXISTS public.app_settings CASCADE;
DROP TABLE IF EXISTS public.daily_stats CASCADE;
DROP TABLE IF EXISTS public.analytics_events CASCADE;
DROP TABLE IF EXISTS public.api_logs CASCADE;
DROP TABLE IF EXISTS public.system_health CASCADE;
DROP TABLE IF EXISTS public.prompt_history CASCADE;
DROP TABLE IF EXISTS public.system_prompts CASCADE;
DROP TABLE IF EXISTS public.admin_users CASCADE;

-- Drop indexes (if they still exist)
DROP INDEX IF EXISTS public.idx_system_alerts_severity;
DROP INDEX IF EXISTS public.idx_system_alerts_acknowledged;
DROP INDEX IF EXISTS public.idx_notifications_user_id;
DROP INDEX IF EXISTS public.idx_notifications_is_read;
DROP INDEX IF EXISTS public.idx_audit_log_user_id;
DROP INDEX IF EXISTS public.idx_audit_log_entity_type;
DROP INDEX IF EXISTS public.idx_audit_log_created_at;
DROP INDEX IF EXISTS public.idx_feature_flags_name;
DROP INDEX IF EXISTS public.idx_app_settings_key;
DROP INDEX IF EXISTS public.idx_app_settings_category;
DROP INDEX IF EXISTS public.idx_daily_stats_date;
DROP INDEX IF EXISTS public.idx_analytics_events_type;
DROP INDEX IF EXISTS public.idx_analytics_events_user_id;
DROP INDEX IF EXISTS public.idx_analytics_events_created_at;
DROP INDEX IF EXISTS public.idx_api_logs_created_at;
DROP INDEX IF EXISTS public.idx_api_logs_user_id;
DROP INDEX IF EXISTS public.idx_api_logs_endpoint;
DROP INDEX IF EXISTS public.idx_system_health_component;
DROP INDEX IF EXISTS public.idx_system_health_checked_at;
DROP INDEX IF EXISTS public.idx_prompt_history_prompt_id;
DROP INDEX IF EXISTS public.idx_system_prompts_category;
DROP INDEX IF EXISTS public.idx_system_prompts_is_active;
DROP INDEX IF EXISTS public.idx_admin_users_user_id;
DROP INDEX IF EXISTS public.idx_admin_users_role;

-- Success message
DO $$
BEGIN
    RAISE NOTICE 'All admin tables and indexes have been dropped successfully.';
    RAISE NOTICE 'Your database is now reverted to the base EduChat schema.';
END $$;
