-- EduChat Migration: Add AI Instructions to Scraper Jobs
-- Run this in Supabase SQL Editor to add AI-powered scraping support

-- Add ai_instructions column for Gemini-powered dynamic scraping
ALTER TABLE scraper_jobs 
ADD COLUMN IF NOT EXISTS ai_instructions TEXT;

-- Add comment for documentation
COMMENT ON COLUMN scraper_jobs.ai_instructions IS 
'Natural language instructions for Gemini AI to analyze pages and generate selectors dynamically. When set, AI will analyze the target URL and determine what to scrape instead of using static selectors.';

-- Update selectors to be nullable (AI can generate them)
ALTER TABLE scraper_jobs 
ALTER COLUMN selectors DROP NOT NULL,
ALTER COLUMN selectors SET DEFAULT NULL;

ALTER TABLE scraper_jobs 
ALTER COLUMN data_mapping DROP NOT NULL,
ALTER COLUMN data_mapping SET DEFAULT NULL;

-- Add error_message to scraper_runs if not exists
ALTER TABLE scraper_runs 
ADD COLUMN IF NOT EXISTS error_message TEXT;

-- ============================================================
-- EMAIL SERVICE ENHANCEMENTS
-- ============================================================

-- Add sent_at column to reminders table for email tracking (sent column already exists)
ALTER TABLE reminders 
ADD COLUMN IF NOT EXISTS sent_at TIMESTAMP WITH TIME ZONE;

-- Add index for finding unsent reminders efficiently
CREATE INDEX IF NOT EXISTS idx_reminders_unsent 
ON reminders(date, sent) 
WHERE sent = FALSE;

-- ============================================================
-- VERIFICATION
-- ============================================================
DO $$
BEGIN
    RAISE NOTICE 'Migration complete: AI instructions added to scraper_jobs, email integration added to reminders';
END $$;
